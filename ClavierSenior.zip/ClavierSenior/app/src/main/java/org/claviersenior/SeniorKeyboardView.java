package org.claviersenior;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Vue du clavier : dessine elle-même les grandes touches (pas de bibliothèque).
 * Tolérante aux tremblements : la touche validée est celle où le doigt s'est posé.
 */
public class SeniorKeyboardView extends View {

    public interface Listener {
        void onKeyPressStart(Key key);
        void onKey(Key key);
    }

    public static final int CODE_CHAR = 0, CODE_SHIFT = -1, CODE_DELETE = -2, CODE_ENTER = -3,
            CODE_SPACE = -4, CODE_TO_NUMBERS = -5, CODE_TO_LETTERS = -6;

    public static final int SHIFT_OFF = 0, SHIFT_ONCE = 1, SHIFT_LOCK = 2;

    public static class Key {
        public final int code;
        public String label;
        public final String text;
        public final float weight;
        final RectF rect = new RectF();

        public Key(int code, String label, String text, float weight) {
            this.code = code;
            this.label = label;
            this.text = text;
            this.weight = weight;
        }
    }

    public static class Row {
        public final List<Key> keys = new ArrayList<>();
        void add(Key k) { keys.add(k); }
        float weight() {
            float w = 0;
            for (Key k : keys) w += k.weight;
            return w;
        }
    }

    private Listener listener;
    private List<Row> rows = new ArrayList<>();
    private Prefs prefs;
    private KbTheme theme = KbTheme.of(0);
    private int shift = SHIFT_OFF;

    private float keyH, stripH, gap, pad, insetBottom;
    private boolean layoutDirty = true;

    private Key pressed;
    private String previewText = "";

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable repeatDelete = new Runnable() {
        @Override public void run() {
            if (pressed != null && pressed.code == CODE_DELETE && listener != null) {
                listener.onKey(pressed);
                handler.postDelayed(this, 120);
            }
        }
    };

    public SeniorKeyboardView(Context c) {
        super(c);
        text.setTextAlign(Paint.Align.CENTER);
        text.setTypeface(Typeface.DEFAULT_BOLD);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        gap = dp(5);
        pad = dp(3);
        prefs = Prefs.load(c);
    }

    public void setListener(Listener l) { listener = l; }

    public void configure(Prefs p, List<Row> newRows, int shiftState, String enterLabel) {
        prefs = p;
        theme = KbTheme.of(p.theme);
        rows = newRows;
        shift = shiftState;
        for (Row r : rows) for (Key k : r.keys) if (k.code == CODE_ENTER) k.label = enterLabel;
        pressed = null;
        layoutDirty = true;
        requestLayout();
        invalidate();
    }

    public void setShiftState(int s) {
        if (s != shift) { shift = s; invalidate(); }
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    // ---------- Mesure & placement ----------

    @Override
    public WindowInsets onApplyWindowInsets(WindowInsets insets) {
        float b;
        if (Build.VERSION.SDK_INT >= 30) {
            b = insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
        } else {
            b = insets.getSystemWindowInsetBottom();
        }
        if (b != insetBottom) { insetBottom = b; requestLayout(); }
        return insets;
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int width = MeasureSpec.getSize(widthSpec);
        int screenH = getResources().getDisplayMetrics().heightPixels;
        int n = Math.max(1, rows.size());
        keyH = dp(prefs.keyHeightDp());
        stripH = prefs.preview ? keyH * 0.8f : 0f;
        float max = screenH * 0.62f; // ne jamais masquer tout l'écran (paysage)
        float total = stripH + n * keyH + 2 * pad;
        if (total > max) {
            float scale = (max - 2 * pad) / (stripH + n * keyH);
            keyH *= scale;
            stripH *= scale;
            total = max;
        }
        layoutDirty = true;
        setMeasuredDimension(width, (int) (total + insetBottom));
    }

    private void layoutKeys() {
        float unit = (getWidth() - 2 * pad) / 10f;
        float y = pad + stripH;
        for (Row r : rows) {
            float x = pad + (10f - r.weight()) * unit / 2f;
            for (Key k : r.keys) {
                float w = k.weight * unit;
                k.rect.set(x + gap / 2, y + gap / 2, x + w - gap / 2, y + keyH - gap / 2);
                x += w;
            }
            y += keyH;
        }
        layoutDirty = false;
    }

    // ---------- Dessin ----------

    @Override
    protected void onDraw(Canvas c) {
        if (layoutDirty) layoutKeys();
        c.drawColor(theme.bg);
        float radius = dp(10);

        if (stripH > 0) {
            fill.setColor(theme.strip);
            RectF s = new RectF(pad + gap / 2, pad + gap / 2, getWidth() - pad - gap / 2, pad + stripH - gap / 2);
            c.drawRoundRect(s, radius, radius, fill);
            if (!previewText.isEmpty()) {
                text.setColor(theme.stripText);
                text.setTextSize(s.height() * 0.75f);
                c.drawText(previewText, s.centerX(), centerY(s), text);
            }
        }

        for (Row r : rows) {
            for (Key k : r.keys) drawKey(c, k, radius);
        }
    }

    private void drawKey(Canvas c, Key k, float radius) {
        int bg, fg;
        boolean isPressed = k == pressed;
        if (isPressed) {
            bg = theme.pressed; fg = theme.pressedText;
        } else if (k.code == CODE_ENTER) {
            bg = theme.action; fg = theme.actionText;
        } else if (k.code == CODE_SHIFT && shift != SHIFT_OFF) {
            bg = theme.shiftOn; fg = 0xFFFFFFFF;
        } else if (k.code == CODE_CHAR || k.code == CODE_SPACE) {
            bg = theme.key; fg = theme.keyText;
        } else {
            bg = theme.special; fg = theme.specialText;
        }
        fill.setColor(bg);
        c.drawRoundRect(k.rect, radius, radius, fill);

        float cx = k.rect.centerX(), cy = k.rect.centerY();
        float s = Math.min(k.rect.width(), k.rect.height()) * 0.28f;

        switch (k.code) {
            case CODE_SHIFT:
                drawShift(c, cx, cy, s, fg);
                return;
            case CODE_DELETE:
                drawDelete(c, cx, cy, s, fg);
                return;
            default:
                String label = displayLabel(k);
                text.setColor(fg);
                float size = k.code == CODE_CHAR ? keyH * 0.5f : keyH * 0.32f;
                text.setTextSize(size);
                float maxW = k.rect.width() * 0.88f;
                while (text.measureText(label) > maxW && size > keyH * 0.18f) {
                    size *= 0.92f;
                    text.setTextSize(size);
                }
                c.drawText(label, cx, centerY(k.rect), text);
        }
    }

    private float centerY(RectF r) {
        Paint.FontMetrics fm = text.getFontMetrics();
        return r.centerY() - (fm.ascent + fm.descent) / 2f;
    }

    private void drawShift(Canvas c, float cx, float cy, float s, int color) {
        cy -= s * 0.15f;
        path.reset();
        path.moveTo(cx, cy - s);
        path.lineTo(cx + s, cy);
        path.lineTo(cx + s * 0.45f, cy);
        path.lineTo(cx + s * 0.45f, cy + s * 0.8f);
        path.lineTo(cx - s * 0.45f, cy + s * 0.8f);
        path.lineTo(cx - s * 0.45f, cy);
        path.lineTo(cx - s, cy);
        path.close();
        if (shift == SHIFT_OFF) {
            stroke.setColor(color);
            stroke.setStrokeWidth(s * 0.16f);
            c.drawPath(path, stroke);
        } else {
            fill.setColor(color);
            c.drawPath(path, fill);
            if (shift == SHIFT_LOCK) { // barre sous la flèche = verrouillé
                c.drawRect(cx - s * 0.6f, cy + s * 1.0f, cx + s * 0.6f, cy + s * 1.25f, fill);
            }
        }
    }

    private void drawDelete(Canvas c, float cx, float cy, float s, int color) {
        stroke.setColor(color);
        stroke.setStrokeWidth(s * 0.16f);
        path.reset();
        path.moveTo(cx - s * 1.3f, cy);
        path.lineTo(cx - s * 0.55f, cy - s * 0.8f);
        path.lineTo(cx + s * 1.2f, cy - s * 0.8f);
        path.lineTo(cx + s * 1.2f, cy + s * 0.8f);
        path.lineTo(cx - s * 0.55f, cy + s * 0.8f);
        path.close();
        c.drawPath(path, stroke);
        float xc = cx + s * 0.32f, d = s * 0.35f;
        c.drawLine(xc - d, cy - d, xc + d, cy + d, stroke);
        c.drawLine(xc - d, cy + d, xc + d, cy - d, stroke);
    }

    String displayLabel(Key k) {
        if (k.code != CODE_CHAR) return k.label;
        if (prefs.upperLabels || shift != SHIFT_OFF) return k.label.toUpperCase(Locale.FRENCH);
        return k.label;
    }

    // ---------- Toucher ----------

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                Key k = findKey(e.getX(), e.getY());
                if (k == null) return true;
                pressed = k;
                if (listener != null) listener.onKeyPressStart(k);
                if (k.code == CODE_CHAR) previewText = displayLabel(k);
                if (k.code == CODE_DELETE && listener != null) {
                    listener.onKey(k);
                    handler.postDelayed(repeatDelete, 550);
                }
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_UP: {
                handler.removeCallbacks(repeatDelete);
                Key k = pressed;
                pressed = null;
                invalidate();
                if (k != null && k.code != CODE_DELETE && listener != null) listener.onKey(k);
                performClick();
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacks(repeatDelete);
                pressed = null;
                invalidate();
                return true;
            default:
                return true; // on ignore les doigts supplémentaires
        }
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }

    /** Touche sous le doigt, ou la plus proche dans la rangée (les espaces entre touches comptent). */
    private Key findKey(float x, float y) {
        if (layoutDirty) layoutKeys();
        Key best = null;
        float bestD = Float.MAX_VALUE;
        for (Row r : rows) {
            if (r.keys.isEmpty()) continue;
            RectF first = r.keys.get(0).rect;
            if (y < first.top - gap / 2 || y > first.bottom + gap / 2) continue;
            for (Key k : r.keys) {
                if (k.rect.contains(x, y)) return k;
                float d = Math.abs(k.rect.centerX() - x) - k.rect.width() / 2;
                if (d < bestD) { bestD = d; best = k; }
            }
        }
        return best;
    }

    public void clearPreview() {
        previewText = "";
        invalidate();
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacks(repeatDelete);
        super.onDetachedFromWindow();
    }
}
