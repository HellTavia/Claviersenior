package org.claviersenior;

import android.text.InputType;
import android.view.inputmethod.EditorInfo;

import java.util.ArrayList;
import java.util.List;

import static org.claviersenior.SeniorKeyboardView.*;

/** Dispositions : lettres AZERTY, chiffres/symboles, pavé téléphone. */
public final class Layouts {
    public static final int MODE_LETTERS = 0, MODE_NUMBERS = 1, MODE_PHONE = 2;

    private Layouts() {}

    public static List<Row> build(int mode, EditorInfo info, Prefs p) {
        int type = info != null ? info.inputType : 0;
        int cls = type & InputType.TYPE_MASK_CLASS;
        int var = type & InputType.TYPE_MASK_VARIATION;

        // Touche à côté de l'espace : « , » ou « @ » (e-mail) ou « / » (adresse web)
        String extra = ",";
        if (cls == InputType.TYPE_CLASS_TEXT) {
            if (var == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
                    || var == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS) extra = "@";
            else if (var == InputType.TYPE_TEXT_VARIATION_URI) extra = "/";
        }

        List<Row> rows = new ArrayList<>();
        switch (mode) {
            case MODE_NUMBERS:
                rows.add(chars("1 2 3 4 5 6 7 8 9 0"));
                rows.add(chars("@ # € & - + ( ) / ?"));
                Row r = chars("! : ; \" * % =");
                r.add(new Key(CODE_DELETE, "", null, 3f));
                rows.add(r);
                rows.add(bottom("ABC", CODE_TO_LETTERS, extra));
                break;

            case MODE_PHONE: {
                boolean phone = cls == InputType.TYPE_CLASS_PHONE;
                Row r1 = chars("1 2 3", 2.5f); r1.add(new Key(CODE_DELETE, "", null, 2.5f));
                Row r2 = chars(phone ? "4 5 6 +" : "4 5 6 -", 2.5f);
                Row r3 = chars(phone ? "7 8 9 *" : "7 8 9 .", 2.5f);
                Row r4 = new Row();
                r4.add(new Key(CODE_TO_LETTERS, "ABC", null, 2.5f));
                r4.add(new Key(CODE_CHAR, "0", "0", 2.5f));
                if (phone) r4.add(new Key(CODE_CHAR, "#", "#", 2.5f));
                else r4.add(new Key(CODE_SPACE, "Espace", " ", 2.5f));
                r4.add(new Key(CODE_ENTER, "OK", null, 2.5f));
                rows.add(r1); rows.add(r2); rows.add(r3); rows.add(r4);
                break;
            }

            default: // Lettres AZERTY
                if (p.accentRow) rows.add(chars("é è à ç ù ê '", 10f / 7f));
                rows.add(chars("a z e r t y u i o p"));
                rows.add(chars("q s d f g h j k l m"));
                Row r3 = new Row();
                r3.add(new Key(CODE_SHIFT, "", null, 1.5f));
                for (String s : "w x c v b n".split(" ")) r3.add(new Key(CODE_CHAR, s, s, 1f));
                r3.add(new Key(CODE_DELETE, "", null, 2.5f));
                rows.add(r3);
                rows.add(bottom("123", CODE_TO_NUMBERS, extra));
                break;
        }
        return rows;
    }

    private static Row bottom(String modeLabel, int modeCode, String extra) {
        Row r = new Row();
        r.add(new Key(modeCode, modeLabel, null, 1.5f));
        r.add(new Key(CODE_CHAR, extra, extra, 1f));
        r.add(new Key(CODE_SPACE, "Espace", " ", 4.5f));
        r.add(new Key(CODE_CHAR, ".", ".", 1f));
        r.add(new Key(CODE_ENTER, "Entrée", null, 2f));
        return r;
    }

    private static Row chars(String spaced) {
        return chars(spaced, 1f);
    }

    private static Row chars(String spaced, float w) {
        Row r = new Row();
        for (String s : spaced.split(" ")) r.add(new Key(CODE_CHAR, s, s, w));
        return r;
    }
}
