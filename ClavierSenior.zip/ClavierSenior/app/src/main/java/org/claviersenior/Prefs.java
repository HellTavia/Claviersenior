package org.claviersenior;

import android.content.Context;
import android.content.SharedPreferences;

/** Réglages du clavier, stockés localement sur le téléphone. */
public class Prefs {
    public static final String FILE = "reglages";

    public static final String SIZE = "taille";          // 0 normale, 1 grande, 2 très grande
    public static final String THEME = "theme";          // 0 clair, 1 sombre, 2 contraste fort
    public static final String VIBRATION = "vibration";  // 0 aucune, 1 légère, 2 forte
    public static final String SOUND = "son";
    public static final String ACCENT_ROW = "ligne_accents";
    public static final String PREVIEW = "apercu";
    public static final String UPPER_LABELS = "lettres_majuscules";
    public static final String AUTO_CAP = "majuscule_auto";

    public int size;
    public int theme;
    public int vibration;
    public boolean sound;
    public boolean accentRow;
    public boolean preview;
    public boolean upperLabels;
    public boolean autoCap;

    public static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public static Prefs load(Context c) {
        SharedPreferences sp = sp(c);
        Prefs p = new Prefs();
        p.size = sp.getInt(SIZE, 1);
        p.theme = sp.getInt(THEME, 0);
        p.vibration = sp.getInt(VIBRATION, 1);
        p.sound = sp.getBoolean(SOUND, false);
        p.accentRow = sp.getBoolean(ACCENT_ROW, true);
        p.preview = sp.getBoolean(PREVIEW, true);
        p.upperLabels = sp.getBoolean(UPPER_LABELS, false);
        p.autoCap = sp.getBoolean(AUTO_CAP, true);
        return p;
    }

    /** Hauteur d'une touche en dp selon la taille choisie. */
    public float keyHeightDp() {
        float[] h = {58f, 72f, 88f};
        return h[Math.max(0, Math.min(2, size))];
    }

    public long vibrationMs() {
        long[] ms = {0L, 20L, 45L};
        return ms[Math.max(0, Math.min(2, vibration))];
    }
}
