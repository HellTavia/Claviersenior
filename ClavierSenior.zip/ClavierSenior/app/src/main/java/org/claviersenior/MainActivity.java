package org.claviersenior;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;

/** Écran d'accueil : activation en 2 étapes, zone d'essai et réglages, en gros caractères. */
public class MainActivity extends Activity {

    private LinearLayout root;
    private TextView status1, status2;
    private SharedPreferences sp;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = Prefs.sp(this);
        Prefs p = Prefs.load(this);

        ScrollView scroll = new ScrollView(this);
        scroll.setFitsSystemWindows(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(18);
        root.setPadding(pad, pad, pad, dp(40));
        scroll.addView(root);
        setContentView(scroll);

        title("Clavier Senior", 32);
        para("Un clavier AZERTY avec de grandes touches, simple et lisible.");

        section("Mise en route");
        bigButton("1.  Activer le clavier", v ->
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        status1 = para("");
        bigButton("2.  Choisir « Clavier Senior »", v -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.showInputMethodPicker();
        });
        status2 = para("");

        section("Essayer");
        EditText test = new EditText(this);
        test.setHint("Touchez ici et écrivez…");
        test.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        test.setMinLines(2);
        test.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        root.addView(test, new LinearLayout.LayoutParams(-1, -2));

        section("Réglages");
        radio("Taille des touches", new String[]{"Normale", "Grande", "Très grande"}, Prefs.SIZE, p.size);
        radio("Couleurs", new String[]{"Clair", "Sombre", "Contraste fort (jaune et noir)"}, Prefs.THEME, p.theme);
        radio("Vibration", new String[]{"Aucune", "Légère", "Forte"}, Prefs.VIBRATION, p.vibration);
        check("Son des touches", Prefs.SOUND, p.sound);
        check("Ligne des accents (é è à ç ù ê ')", Prefs.ACCENT_ROW, p.accentRow);
        check("Grande bulle qui montre la lettre tapée", Prefs.PREVIEW, p.preview);
        check("Toujours afficher les lettres en MAJUSCULES", Prefs.UPPER_LABELS, p.upperLabels);
        check("Majuscule automatique en début de phrase", Prefs.AUTO_CAP, p.autoCap);

        section("Astuces");
        para("• Touche flèche (majuscule) : une fois = une majuscule. Deux fois vite = tout en majuscules.\n"
                + "• Garder le doigt sur Effacer efface en continu.\n"
                + "• 123 : chiffres et symboles. ABC : retour aux lettres.");

        TextView foot = para("Logiciel libre et gratuit (licence MIT). Aucune publicité, "
                + "aucune connexion Internet, aucune donnée collectée.");
        foot.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) refreshStatus(); // après la fenêtre de choix du clavier
    }

    private void refreshStatus() {
        if (status1 == null) return;
        boolean enabled = false;
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            for (InputMethodInfo i : imm.getEnabledInputMethodList()) {
                if (getPackageName().equals(i.getPackageName())) { enabled = true; break; }
            }
        }
        String current = Settings.Secure.getString(getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
        boolean selected = current != null && current.startsWith(getPackageName() + "/");
        status1.setText(enabled ? "✔ Clavier activé" : "✘ Pas encore activé");
        status1.setTextColor(enabled ? 0xFF2E7D32 : 0xFFC62828);
        status2.setText(selected ? "✔ C'est le clavier utilisé" : "✘ Pas encore choisi");
        status2.setTextColor(selected ? 0xFF2E7D32 : 0xFFC62828);
    }

    // ---------- Petits outils d'interface ----------

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView title(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(t);
        return t;
    }

    private void section(String s) {
        TextView t = title(s, 26);
        t.setPadding(0, dp(26), 0, dp(8));
    }

    private TextView para(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        t.setPadding(0, dp(6), 0, dp(6));
        root.addView(t);
        return t;
    }

    private void bigButton(String s, View.OnClickListener l) {
        Button btn = new Button(this);
        btn.setText(s);
        btn.setAllCaps(false);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        btn.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        btn.setMinHeight(dp(72));
        btn.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(8);
        root.addView(btn, lp);
    }

    private void radio(String label, String[] options, final String key, int selected) {
        TextView t = para(label);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        RadioGroup g = new RadioGroup(this);
        for (int i = 0; i < options.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(1000 + i);
            rb.setText(options[i]);
            rb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
            rb.setMinHeight(dp(56));
            g.addView(rb);
        }
        g.check(1000 + selected);
        g.setOnCheckedChangeListener((group, id) -> sp.edit().putInt(key, id - 1000).apply());
        root.addView(g);
    }

    private void check(String label, final String key, boolean value) {
        CheckBox cb = new CheckBox(this);
        cb.setText(label);
        cb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        cb.setMinHeight(dp(60));
        cb.setChecked(value);
        cb.setOnCheckedChangeListener((b, checked) -> sp.edit().putBoolean(key, checked).apply());
        root.addView(cb);
    }
}
