package org.claviersenior;

/** Jeux de couleurs du clavier (contrastes élevés). */
public class KbTheme {
    public int bg, key, keyText, special, specialText, action, actionText,
            pressed, pressedText, strip, stripText, shiftOn;

    public static KbTheme of(int id) {
        KbTheme t = new KbTheme();
        switch (id) {
            case 1: // Sombre
                t.bg = 0xFF000000;
                t.key = 0xFF303030;      t.keyText = 0xFFFFFFFF;
                t.special = 0xFF4A4A4A;  t.specialText = 0xFFFFFFFF;
                t.action = 0xFF1565C0;   t.actionText = 0xFFFFFFFF;
                t.pressed = 0xFFFFFFFF;  t.pressedText = 0xFF000000;
                t.strip = 0xFF1A1A1A;    t.stripText = 0xFFFFFFFF;
                t.shiftOn = 0xFF42A5F5;
                break;
            case 2: // Contraste fort : jaune sur noir
                t.bg = 0xFF000000;
                t.key = 0xFFFFD600;      t.keyText = 0xFF000000;
                t.special = 0xFFFFFFFF;  t.specialText = 0xFF000000;
                t.action = 0xFF00C853;   t.actionText = 0xFF000000;
                t.pressed = 0xFF2962FF;  t.pressedText = 0xFFFFFFFF;
                t.strip = 0xFF000000;    t.stripText = 0xFFFFD600;
                t.shiftOn = 0xFF2962FF;
                break;
            default: // Clair
                t.bg = 0xFFC9CFD6;
                t.key = 0xFFFFFFFF;      t.keyText = 0xFF000000;
                t.special = 0xFFA9B3BF;  t.specialText = 0xFF000000;
                t.action = 0xFF1565C0;   t.actionText = 0xFFFFFFFF;
                t.pressed = 0xFF0D47A1;  t.pressedText = 0xFFFFFFFF;
                t.strip = 0xFFFFFFFF;    t.stripText = 0xFF000000;
                t.shiftOn = 0xFF1565C0;
                break;
        }
        return t;
    }
}
