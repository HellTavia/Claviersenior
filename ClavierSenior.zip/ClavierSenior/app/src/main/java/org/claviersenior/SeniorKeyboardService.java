package org.claviersenior;

import android.content.Context;
import android.content.SharedPreferences;
import android.inputmethodservice.InputMethodService;
import android.media.AudioManager;
import android.os.Build;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;

import java.util.Locale;

import static org.claviersenior.SeniorKeyboardView.*;

/** Le service clavier lui-même. Aucune connexion Internet, rien n'est enregistré. */
public class SeniorKeyboardService extends InputMethodService
        implements SeniorKeyboardView.Listener, SharedPreferences.OnSharedPreferenceChangeListener {

    private SeniorKeyboardView view;
    private Prefs prefs;
    private EditorInfo editorInfo;
    private int mode = Layouts.MODE_LETTERS;
    private int shift = SHIFT_OFF;
    private long lastShiftTap;

    private Vibrator vibrator;
    private AudioManager audio;

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = Prefs.load(this);
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(this);
    }

    @Override
    public void onDestroy() {
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(this);
        super.onDestroy();
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
        prefs = Prefs.load(this);
        rebuild();
    }

    @Override
    public View onCreateInputView() {
        view = new SeniorKeyboardView(this);
        view.setListener(this);
        rebuild();
        return view;
    }

    /** Jamais de mode plein écran (même en paysage) : on garde le texte visible. */
    @Override
    public boolean onEvaluateFullscreenMode() {
        return false;
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        editorInfo = info;
        prefs = Prefs.load(this);
        int cls = info.inputType & InputType.TYPE_MASK_CLASS;
        if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE
                || cls == InputType.TYPE_CLASS_DATETIME) {
            mode = Layouts.MODE_PHONE;
        } else if (!restarting) {
            mode = Layouts.MODE_LETTERS;
        }
        if (!restarting) shift = SHIFT_OFF;
        updateAutoShift();
        rebuild();
        if (view != null) view.clearPreview();
    }

    @Override
    public void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart, int newSelEnd,
                                  int candidatesStart, int candidatesEnd) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd,
                candidatesStart, candidatesEnd);
        updateAutoShift();
    }

    private void rebuild() {
        if (view == null) return;
        view.configure(prefs, Layouts.build(mode, editorInfo, prefs), shift, enterLabel());
    }

    /** Majuscule automatique en début de phrase, si le champ le demande. */
    private void updateAutoShift() {
        if (shift == SHIFT_LOCK || editorInfo == null) return;
        int newShift = SHIFT_OFF;
        InputConnection ic = getCurrentInputConnection();
        if (prefs.autoCap && ic != null && editorInfo.inputType != InputType.TYPE_NULL) {
            if (ic.getCursorCapsMode(editorInfo.inputType) != 0) newShift = SHIFT_ONCE;
        }
        shift = newShift;
        if (view != null) view.setShiftState(shift);
    }

    private String enterLabel() {
        if (editorInfo == null) return "Entrée";
        if (editorInfo.actionLabel != null && editorInfo.actionLabel.length() > 0) {
            return editorInfo.actionLabel.toString();
        }
        if (hasEnterAction()) {
            switch (editorInfo.imeOptions & EditorInfo.IME_MASK_ACTION) {
                case EditorInfo.IME_ACTION_GO: return "Aller";
                case EditorInfo.IME_ACTION_SEARCH: return "Chercher";
                case EditorInfo.IME_ACTION_SEND: return "Envoyer";
                case EditorInfo.IME_ACTION_NEXT: return "Suivant";
                case EditorInfo.IME_ACTION_PREVIOUS: return "Retour";
                case EditorInfo.IME_ACTION_DONE: return "OK";
                default: break;
            }
        }
        return mode == Layouts.MODE_PHONE ? "OK" : "Entrée";
    }

    private boolean hasEnterAction() {
        if (editorInfo == null) return false;
        if ((editorInfo.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return false;
        int a = editorInfo.imeOptions & EditorInfo.IME_MASK_ACTION;
        return a != EditorInfo.IME_ACTION_NONE && a != EditorInfo.IME_ACTION_UNSPECIFIED;
    }

    // ---------- Retour tactile / sonore ----------

    @Override
    public void onKeyPressStart(Key key) {
        long ms = prefs.vibrationMs();
        if (ms > 0 && vibrator != null && vibrator.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= 26) {
                vibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vibrator.vibrate(ms);
            }
        }
        if (prefs.sound && audio != null) {
            int fx = AudioManager.FX_KEYPRESS_STANDARD;
            if (key.code == CODE_DELETE) fx = AudioManager.FX_KEYPRESS_DELETE;
            else if (key.code == CODE_SPACE) fx = AudioManager.FX_KEYPRESS_SPACEBAR;
            else if (key.code == CODE_ENTER) fx = AudioManager.FX_KEYPRESS_RETURN;
            audio.playSoundEffect(fx, -1f);
        }
    }

    // ---------- Frappe ----------

    @Override
    public void onKey(Key key) {
        InputConnection ic = getCurrentInputConnection();
        switch (key.code) {
            case CODE_CHAR: {
                if (ic == null) return;
                String t = shift != SHIFT_OFF ? key.text.toUpperCase(Locale.FRENCH) : key.text;
                ic.commitText(t, 1);
                if (shift == SHIFT_ONCE) shift = SHIFT_OFF;
                break;
            }
            case CODE_SPACE:
                if (ic != null) ic.commitText(" ", 1);
                break;
            case CODE_DELETE:
                sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
                break;
            case CODE_ENTER:
                if (ic == null) return;
                if (hasEnterAction()) {
                    ic.performEditorAction(editorInfo.imeOptions & EditorInfo.IME_MASK_ACTION);
                } else {
                    sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
                }
                break;
            case CODE_SHIFT: {
                long now = SystemClock.uptimeMillis();
                if (shift == SHIFT_LOCK) shift = SHIFT_OFF;
                else if (shift == SHIFT_ONCE && now - lastShiftTap < 450) shift = SHIFT_LOCK; // double appui
                else if (shift == SHIFT_ONCE) shift = SHIFT_OFF;
                else shift = SHIFT_ONCE;
                lastShiftTap = now;
                break;
            }
            case CODE_TO_NUMBERS:
                mode = Layouts.MODE_NUMBERS;
                rebuild();
                return;
            case CODE_TO_LETTERS:
                mode = Layouts.MODE_LETTERS;
                rebuild();
                updateAutoShift();
                return;
            default:
                break;
        }
        if (view != null) view.setShiftState(shift);
    }
}
