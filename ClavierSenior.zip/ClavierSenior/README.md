# Clavier Senior

Clavier Android **AZERTY à grandes touches**, libre (MIT) et gratuit, dans l'esprit de BaldPhone.
Aucune publicité, aucune permission Internet, aucune donnée collectée — seule permission : la vibration.

![Aperçu](apercu.png)

## Fonctions
- AZERTY français, touches de 58 / 72 / 88 dp (3 tailles), texte en gras
- Ligne d'accents directe : é è à ç ù ê ' (pas d'appui long à maîtriser)
- Grande bulle en haut qui affiche la lettre tapée
- 3 thèmes : clair, sombre, contraste fort jaune/noir
- Tolérant aux tremblements : c'est la touche où le doigt s'est posé qui compte ; un 2e doigt posé est ignoré
- Majuscule : 1 appui = une lettre, 2 appuis rapides = verrouillé (barre sous la flèche)
- Majuscule automatique en début de phrase
- Effacer : maintenir pour effacer en continu (lent, pour ne pas tout perdre)
- Pavé numérique géant automatique pour les champs téléphone / nombre
- `@` remplace la virgule dans les champs e-mail, `/` dans les adresses web
- Touche Entrée qui dit ce qu'elle fait : « Envoyer », « Chercher », « OK »…
- Vibration (aucune/légère/forte) et son réglables
- Jamais en plein écran, même en paysage (limité à ~60 % de la hauteur)
- Android 5.0 et plus, APK sans aucune bibliothèque (~30 Ko)

## Compiler
**Android Studio** : ouvrir le dossier, puis *Build › Build APK(s)*.

**Ligne de commande** (SDK Android installé) :
```
./gradlew assembleRelease
```
APK : `app/build/outputs/apk/release/app-release.apk`

**Sans rien installer (GitHub)** : pousser le dossier dans un dépôt GitHub ;
l'action *Construire l'APK* compile toute seule, l'APK est dans l'onglet *Actions › artefacts*.

L'APK release est signé avec la clé de debug pour s'installer directement.
Pour une diffusion publique (F-Droid, etc.), configurez votre propre clé.

## Installer chez la personne
1. Installer l'APK, ouvrir « Clavier Senior »
2. Bouton **1. Activer le clavier** → cocher Clavier Senior
3. Bouton **2. Choisir « Clavier Senior »**
4. Régler taille et couleurs, essayer dans la zone de test

## Code
| Fichier | Rôle |
|---|---|
| `SeniorKeyboardService.java` | Service clavier (frappe, majuscules, Entrée, vibration) |
| `SeniorKeyboardView.java` | Dessin des touches et gestion du toucher |
| `Layouts.java` | Dispositions AZERTY / 123 / téléphone |
| `KbTheme.java` | Couleurs |
| `Prefs.java` | Réglages |
| `MainActivity.java` | Écran d'accueil et réglages |

## Pistes
- Lecture des touches par TalkBack (ExploreByTouchHelper)
- Dictée vocale, suggestions de mots
